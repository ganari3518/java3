package AWT_Layout;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;

public class AWT02 extends Frame{
	AWT02(){
		setTitle("AWT ����");
		BorderLayout border = new BorderLayout(5,5);
		setLayout(border);
		Init();
		setSize(250, 200);
		setVisible(true);
	}
	public void Init() {
		add(new Button("��ư1"),"North");
		add(new Button("��ư2"),BorderLayout.WEST);
		add(new Button("��ư3"),"East");
		add(new Button("��ư4"),"South");
		add(new Button("��ư5"),"Center");
	}
	public static void main(String[] args) {
		Frame f =new AWT02();
	}

}
