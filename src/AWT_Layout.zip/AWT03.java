package AWT_Layout;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;

public class AWT03 extends Frame{
	AWT03(){
		setTitle("AWT ����");
		setLayout(new GridLayout(2, 3, 5, 5));
		Init();
		setSize(250, 200);
		setVisible(true);
	}
	public void Init() {
		add(new Button("��ư1"));
		add(new Button("��ư2"));
		add(new Button("��ư3"));
		add(new Button("��ư4"));
		add(new Button("��ư5"));
	}
	public static void main(String[] args) {
		Frame f =new AWT03();
	}

}
