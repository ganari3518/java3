package AWT_Layout;

import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;

public class AWT01 extends Frame{
	AWT01(){
		setTitle("AWT ����");
		setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
		Init();
		setSize(200, 200);
		setVisible(true);
	}
	public void Init() {
		Button firstb = new Button("��ư1");
		add(firstb);
		Button secondb = new Button("��ư2");
		add(secondb);
		add(new Button("��ư3"));
		add(new Button("��ư4"));
		add(new Button("��ư5"));
	}
	public static void main(String[] args) {
		Frame f =new AWT01();
	}

}
